<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>
</title>
<style>
</style>
</head>
<body>
<div class="menubar">
<ul>
<li>
	<a href="student_home.php">HOME</a>
</li>

<li>
	<a href="report_attend.php">ATTENDANCE</a>
</li>
<li>
	<a href="leave.php">APPLY LEAVE</a>
</li>
<li>
	<a href="student_profile.php">PROFILE</a>
</li>
<li>
	<a href="logout.php">LOG OUT</a>
</li>
</ul>
</div>
