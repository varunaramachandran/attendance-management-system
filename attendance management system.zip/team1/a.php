
<h1 align="center">Welcome <?php session_start(); if(isset($_SESSION["sname"]))
{
				echo $_SESSION["sname"];	 
			}?> </h1>
