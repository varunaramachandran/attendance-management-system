<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>
</title>
<style>
</style>
</head>
<body>
<div class="menubar">
<ul>
<li>
	<a href="index.php">HOME</a>
</li>
<li>
	<a href="registration.php">ENROLL</a>
</li>
<li>
	<a href="#">CONTACT</a>
</li>



<li>
	<a href="login1.php">LOGIN</a>
</li>
</ul>
</div>
