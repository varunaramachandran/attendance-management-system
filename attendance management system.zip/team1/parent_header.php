<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>
</title>
<style>
</style>
</head>
<body>
<div class="menubar">
<ul>
<li>
	<a href="parent_home.php">HOME</a>
</li>

<li>
	<a href="parent_profile.php">PROFILE</a>
</li>
<li>
	<a href="logout.php">LOGOUT</a>
</li>
</ul>
</div>
