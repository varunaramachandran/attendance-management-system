<form method="post" action="a.php">
<label for="name"> Name </label>
<input type="text" name="name">
<input type="submit"name="sub"> 
</form>
