<?php
  $con=new mysqli("localhost","root","","prince");
  if($con->connect_error)
  {
	  die("connection faield".$con->connect_error);
  }
  else
  {
	 echo "prince peter";
  }
  
 
?>