<?php 

/* author Arun   */

include('dbcon.php');
if(isset($_post["batch"]))
{}

?>

<html>
<center>
<div>
<body>
<form>
<table> 
   <tr>
        <td>BATCH:</td>
             <td>
		         <?php
						include('dbcon.php');
						$sql="select * from  batch";
						$res=$con->query($sql);
						echo '<select name="ff">';
						echo '<option> ----- </option>';
						while($row=$res->fetch_assoc())
							{
								echo'<option value="'.$row['b_name'].'">'.$row['b_name'].'</option>';
							}
						echo "<select name='ff'>";
						echo '</select>';

				?>
			</td>
	</tr>
	<tr>
        <td>COURSE:</td><td><?php
						include('dbcon.php');
						$sql="select * from  courses";
						$res=$con->query($sql);
						echo '<select name="ff">';
						echo '<option> ------- </option>';
						while($row=$res->fetch_assoc())
							{
								echo'<option value="'.$row['course_name'].'">'.$row['course_name'].'</option>';
							}
						echo "<select name='ff'>";
						echo '</select>';

				?></td>
	</tr>
	<tr>
        <td>DIVISION:</td><td><?php
						include('dbcon.php');
						$sql="select * from  division";
						$res=$con->query($sql);
						echo '<select name="ff">';
						echo '<option> ------- </option>';
						while($row=$res->fetch_assoc())
							{
								echo'<option value="'.$row['division_name'].'">'.$row['division_name'].'</option>';
							}
						echo "<select name='ff'>";
						echo '</select>';
				?></td>
	</tr>
	<tr>
        <td>STUDENT_ID:</td><td> 	<?php 
		
						$sql12="SELECT u_id FROM `users` WHERE user_type='student'";
						$res=$con->query($sql12);
		echo '<select name="uid">';
		echo '<option> ---------- </option>';				
		while($row=$res->fetch_assoc())
		{
		echo '<option value="'.$row['u_id'].'">'.$row['u_id'].'</option>';
		}	
echo "<select name='uid'>";		
		echo '</select>';
		$id=(isset($_POST['uid']) ? $_POST['uid'] : '');
		
		echo (isset($_POST['uid']) ? $_POST['uid'] : '');
		?> </td>
		<script>
</script>

		
	</tr>
	<tr>
        <td>NAME:</td>
		
		<td><input type="text" value="<?php 
				$sql="SELECT u_name FROM `users` WHERE u_id='$id'";
				$res=$con->query($sql);
				while($row=$res->fetch_assoc())
				{
					echo $row['u_name'];
				}		
				?>"></td>
	</tr>
	<tr>
        <td><input type="SUBMIT" name="submit" value="submit"></td>
		</tr>
</form>
</body>
</div>
</center>
</html>

