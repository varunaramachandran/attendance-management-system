<?php session_start(); ?>
<?php include('header2.php'); ?>
<center>
<?php 
if($_SESSION["sname"])
{ 
 
?>
<br><br><br>
<h2> Welcome <?php echo $_SESSION["sname"]; ?> </h2>
<br><br><br><br><br><br>
<p> This Page is to allow Edit and Remove Personal Details Only </p>

<h3> <a href="update.php"> Update Details </a> </h3>
<h3> <a href="delete.php"> Remove Details </a> </h3> 
<?php } 
else
{
	echo "login ";
}


$sql="select * from users where u_name='$uname' or email='$uname'";
  
  $result=$con->query($sql);

foreach($result as $row)
{
	echo "<br>";
	echo "<tr>";
	echo "<td>".$row['batch']."</td>";
	echo "<td>".$row['course']."</td>";
	echo "<td>".$row['division']."</td>";
	echo "<td>".$row['s_id']."</td>";
	echo "<td>".$row['name']."</td>";
	echo "</tr>";
	
}
?>
<?php include('footer.php'); ?>