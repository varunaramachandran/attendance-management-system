<!DOCTYPE html>
<head>
<link rel="stylesheet" href="style.css" type="text/css">
<title> Arun Sir Project </title>
</head>
<body class="bc">

<div class="menubar">
  <ul>
	<li> <a href="index.php">Home </a> </li>
	<li> <a href="register.php">Registeration</a></li>
	<li> <a href="login.php">Login</a> </li>
	<li> <a href="">About us</a>
	
	<div class="submenu">
	<ul>
		<li> <a href="#">vision </a> </li>
		<li> <a href="#">Mission</a></li>
	</ul> 
	</div></li>
	<li> <a href="contact.html">Contact us </a> </li>
  </ul>
</div>
