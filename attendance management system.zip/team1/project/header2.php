<!DOCTYPE html>
<head>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body class="userhome">

<div class="menubar">
  <ul>
	<li> <a href="userhome.php">Home </a> </li>
	<li> <a href="update.php">Edit Profile</a> </li>
	<li> <a href="delete.php">Delete</a> </li>
	<li> <a href="logout.php">Logout</a> </li>
</div>
