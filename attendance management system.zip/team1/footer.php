<center><h6 style="background-color:black;padding:20px;font-size:20px;color:white">&copy 2018-2019 company.inc</h6></center>
</body>

</html>