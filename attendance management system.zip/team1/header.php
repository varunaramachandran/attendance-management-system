<!doctype html>
<html lang="en">

<head>
<title>Attendance manegement</title>
</head>

<body>

	<center><h1 style="background-color:#5b80a4;padding:10px;">Orisys India-Attendance Manegement System</h1></center>