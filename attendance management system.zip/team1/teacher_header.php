<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>
</title>
<style>
</style>
</head>
<body>
<div class="menubar">
<ul>
<li>
	<a href="teacher_home.php">HOME</a>
</li>

<li>
	<a href="attend.php">ATTENDANCE</a>
</li>
<li>
	<a href="leave_approve_selection.php">APPROVE LEAVE</a>
</li>
<li>
	<a href="profile.php">PROFILE</a>
</li>
<li>
	<a href="logout.php">LOG OUT</a>
</li>
</ul>
</div>
