<?php include("header.php");
include("head.php");
?>
<?php include("dbcon.php");?>



<!DOCTYPE HTML>
<html>
<head>

<title></title>
<style>

</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>



<?php include("footer.php");?>