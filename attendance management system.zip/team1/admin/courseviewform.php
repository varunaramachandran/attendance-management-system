<?php include('../dbcon.php'); ?>




<!DOCTYPE html>
<html>
<head><title></title>
<style>

</style>

</head>
<body>
<form method="post">
<center>
<table>
<tr>
        <td>SELECT BATCH : </td><td>
		         <?php
						$sql="SELECT * FROM batch";
						$res=$conn->query($sql);
					
				
						echo '<select name="batch">';
						echo '<option> Choice </option>';
						while($row=$res->fetch_assoc())
						{
							echo'<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
						}
						
						echo '</select>';

					?></td>
	</tr>
	<tr></tr>
	<tr>  <td></td> <td><input type="submit" name="submit" value="view"> </td></tr>
<table>
</form>
</body>
</html>

<?php
 if(isset($_POST['submit']))
 {
	 if ($_POST['batch']=="Choice")
	 {
		 echo "error";
	 }
	 else{
	 $r=$_POST['batch'];
	echo $r;
         }
 }

 ?>