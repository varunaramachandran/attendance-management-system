<!-- author:Linu  -->

<?php include('../header.php'); 
include('admin_header.php');
include('../dbcon.php');

$sql1="select username from login where status=0";
$res=$conn->query($sql1); 
echo '<center> <br><h1> Verify Users </h1><br><form method="POST"><table border="1"> ';
echo '<tr> <th> Name </th><th> Usertype </th><th> Gender </th><th> Email </th> <th> Mobile </th><th>Date of Joining </th>
<th> Qualification</th><th> Username </th> </tr>';

//$sql2="select u_name,user_type from users where"
while($row=$res->fetch_assoc())
{
    $name=$row['username'];
	//echo $name;
	$sql2="select * from users where username='$name'";
	$res2=$conn->query($sql2);
	foreach($res2 as $row)
	{
		echo '<tr> <td>';
		echo $row['u_name'];
		echo '</td> <td>';
		
		
		$ut= $row['user_type'];
		$check="select roll_name from user_roles where roll_value='$ut'";
		
		$z=$conn->query($check);
		foreach ($z as $r)
		{
			echo $r['roll_name'];
		}
		
		echo '</td> <td>'.$row['gender'].' </td> 
		<td>'.$row['email'].'</td> <td>'.$row['mobile'].'</td> <td>'.$row['doj'].'</td> 
		<td>'.$row['qualification'].'</td> <td>'.$row['username'].'</td> <td>';
		
		
		echo '<input type="submit" name="'.$row['u_id'].'" value="Approve">';
		
		echo '</td> </tr>';
		
		
		
	}
	
	foreach($res2 as $row)
		{
			if(isset($_POST[$row['u_id']]) and $row['u_id'])
			{
			$s="update login set status=1 where username='".$row['username']."'";
			$result=$conn->query($s);
			if($result)
			{
				echo '<script> alert("Approved"); </script>'; 
				header("location:approve.php");
				
			}
			else
			{
				echo '<script> alert("error"); </script>';
			}
			
			
				
			}

		}
}

echo '</table> </form></center>';		
	
?>

<br>
<br>


<?php include("../footer.php");?>