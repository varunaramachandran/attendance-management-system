<style>
.b a h2:hover{

background-color:orange;
display:block;
border-radius:30px;
width:100px;
height:30px;
text-align:center;
position:static;
}
.b{margin-left:20px;
margin-top:20px;
width:80px;
}
</style>

<?php include("../header.php"); ?>
<?php include("admin_header.php");?>

<?php
include('../dbcon.php');
$c_id= $_GET['id'];
echo'<div class="b">';

echo'<a href="cview.php"><h2>BACK</h2></a>';
 echo'</div>';

$sql="select * from courses where course_id='$c_id'";
//echo $sql;
$res=$conn->query($sql);
echo'<h1  align="center">EDIT DETAILS</h1>';
echo'<form name="form" style="margin:10px" method="post">';
echo'<center>';
echo'<div style="border:3px solid red;width:500px;height:250px;margin-top:10px;background-color:#99BED3">';
echo '<table align="center" style="padding:10px;margin:10px"> <tr><td> ';
foreach ($res as $row)
{
	
	echo '<tr> <td> Course Name:</td> <td><input type="text" name="course_name" value="'.$row['course_name'].'" </td> </tr>';
	
	echo '<tr> <td> Course Duration:</td> <td><input type="text" name="course_duration" value=" '.$row['course_duration'].'" </td> </tr>';
	echo '<tr> <td> Course Description:</td> <td><input type="text" name="course_desc" value=" '.$row['course_desc'].'" </td> </tr>';
    echo '<tr><td><input type="submit" name="Update" value="Update"></td><td><input type="submit" name="Delete" value="Delete"</td></tr>';
	
	
}
echo'</table>';
echo '</div>';
echo '</center>';

if(isset($_POST["Update"]))
{ 	
$course_name=$_POST['course_name'];
		$course_duration=$_POST['course_duration'];
		$course_desc=$_POST['course_desc'];

		$sql2="update courses set course_name='$course_name',course_duration='$course_duration',course_desc='$course_desc' where course_id='$c_id'";
		//echo $sql2;
		
		if ($conn->query($sql2) === TRUE) 
		{
          echo "<script> alert('Updated successfully'); window.location='cview.php'; </script>";
		}
		else {
			echo "Error: " . $sql2 . "<br>" . $conn->error;
		}

$conn->close();
		
		
		

}
if(isset($_POST["Delete"]))
{ 	

		$sql2="delete from  courses where course_id='$c_id'";
		//echo $sql2;
		
		if ($conn->query($sql2) === TRUE) {
    echo "Deleted successfully";
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
		
		
		

}


?>

<?php include('../footer.php'); ?>