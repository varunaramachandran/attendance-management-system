<!-- coded by joish 
	validation : Client side[java script]

-->
<?php include('../dbcon.php');
include('../admin_header.php'); ?>

<?php include('../header.php'); ?>
<!DOCTYPE html>
<html>
<head><title>view</title>
<style>
table{
	text-align:center;
	border-collapse:collapse;
	width:50%;
	color:black;
	text-align:left;
	font-family:comic sans MS;
	
}
td,th{
	text-align:center;
}
th{
	background-color:#d96455;
}
</style>
</head>
<body>
<center>
<form name="create" method="post" >

<strong>BATCH</strong>

<?php

$sql="select * from batch";

$res=$conn->query($sql);

echo '<select name="batch" >';
echo '<option value="0">select</option>';
while($row=$res->fetch_assoc())
{
	echo '<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
}
echo '</select>'
?>
<br><br>
<a href="admin_batch.php"><h2>BACK</h2>
<br><br>
<input type="submit" name="submit" value="submit"><br><br><br>

<?php
if(isset($_POST["submit"]))
{
	
	?> 
	
	<table border="">
<tr>
<th>BATCH-NAME</th>
<th>START-AT</th>
<th>END-AT</th>
<th>BATCH-DESCRIPTION<th>
<th>EDIT</th>
</tr>
<?php
$batch=$_POST['batch'];
$sql="SELECT b_id,b_name,start_at,end_at,batch_desc from batch where b_id='$batch' ";

$res=$conn->query($sql);

if($res)
{

while($row=$res->fetch_assoc())
	
{
	$id=$row['b_id'];

	echo "<tr><td>".$row["b_name"]."</td><td>".$row["start_at"]."</td><td>".$row["end_at"]."</td><td>".$row["batch_desc"]."</td><td></td>"; ?> 
	<td><a href="batch_edit2.php?id=<?php echo $id; ?> ">Edit</a></td>
	<?php 
}
echo "</table>";
}
else{
	echo "0 result";
}
$conn-> close();
} ?>
</table> 
</body>
</html>

<?php include('../footer.php'); ?>