<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>
</title>
<style>
</style>
</head>
<body>
<div class="menubar">
<ul>
<li>
	<a href="admin_home.php">HOME</a>
</li>

<li>
	<a href="approve.php">APPROVE</a>
</li>

<li>
	<a href="../logout.php">LOGOUT</a>
</li>
</ul>
</div>
