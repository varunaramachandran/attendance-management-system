<?php include("../header.php");
include('admin_header.php');?>

<style>.a{display:inline-flex;padding:30px}
a{color:white;text-decoration:none}

</style>
<h1 align="center">MANAGE STUDENT</h1>
<div class="a">
<div style="border:2px solid red;width:150px;height:330px;border-radius:10px;background-color:#BC7D6F;">
<ul>
<li><a href="admin_batch.php">BATCH</a></li><br><br>
<li><a href="admin_course.php">COURSE</a></li><br><br>
<li><a href="admin_division.php">DIVISION</a></li><br><br>
<li><a href="manage_staff_admin.php">STAFF</a></li><br><br>
<li><a href="manage_student_admin.php">STUDENT</a></li><br><br>
<li><a href="admin_parent.php">PARENTS</a></li><br><br>
</ul>
</div>
<div align="center" style="border:2px solid red;width:500px;height:200px;margin-left:220px;border-radius:10px;background-color:#BC7D6F">
<ul>
<a href="">ADD</a><br><br>
<a href="">EDIT</a><br><br>
<a href="">VIEW</a><br><br>
<a href="">LOGOUT</a><br><br>
</ul>
</div>

<div style="border:2px solid red;width:150px;height:200px;margin-left:220px;border-radius:10px;background-color:#BC7D6F">
<ul>
<li><a href="">ATTENDENCE</a></li><br><br>
<li><a href="">LEAVE</a></li><br><br>
<li><a href="admin_report.php">REPORT</a></li><br><br>
</ul>
</div>
</div>



<?php include("../footer.php");?>
