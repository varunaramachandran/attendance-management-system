<?php include('../dbcon.php'); ?>

<?php include('../header.php'); ?>
<?php include("admin_header.php");?>
<!DOCTYPE html>
<html>
<head><title>view</title>
<style>
.b a h2:hover{

background-color:orange;
display:block;
border-radius:30px;
width:100px;
height:30px;
text-align:center
}
.b{margin-right:1300px;
margin-top:20px;
width:80px;
}

table{
	text-align:center;
	border-collapse:collapse;
	width:50%;
	color:black;
	text-align:left;
	font-family:comic sans MS;
	
}
td,th{
	text-align:center;
}
th{
	background-color:#d96455;
}
</style>
</head>
<body>
<center>
<div class="b">

<a href="admin_course.php"><h2>BACK</h2></a>
 </div>
<form name="create" method="post" >

<strong>BATCH</strong>
<?php
$sql="select * from batch";
$res=$conn->query($sql);
echo '<select name="batch" >';
echo '<option>select</option>';
while($row=$res->fetch_assoc())
{
	echo '<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
}
echo '</select>'
?>
<br><br>
<input type="submit" name="submit" value="submit"><br><br><br>

<?php
if(isset($_POST["submit"]))
{
	
	?> 
	<table border="">
<tr>
<th>COURSE-NAME</th>
<th>COURSE DURATION</th>
<th>DESCRIPTION</th>
<th>EDIT</th>
</tr>
<?php
$batch=$_POST['batch'];
$sql="SELECT course_id,course_name,course_duration,course_desc from courses where batch_id='$batch' ";
$res=$conn->query($sql);
#echo $sql;
if($res)
{
if($res->num_rows > 0)
{
while($row=$res->fetch_assoc())
	
{
	$id=$row["course_id"];

	echo "<tr><td>".$row["course_name"]."</td><td>".$row["course_duration"]."</td><td>".$row["course_desc"]."</td>"; ?> 
	<td><a href="course_edit.php?id= <?php echo $id; ?> ">Edit</a></td>
	<?php 
}
echo "</table>";
}
else{
	echo "0 result";
}
$conn-> close();
} }?>
</table> 
</body>
</html>
<br><br>
<?php include('../footer.php'); ?>