<!--
Author :Rahul Prasad 
client side validation 
server side validation
Data Base Administration
 -->


<?php include("../header.php");?>
<?php include("admin_header.php");?>

<?php 
include('../dbcon.php'); 

if(isset($_POST['submit']))
{
	$course_name = trim($_POST['course_name']);
 	$course_duration = trim($_POST['course_duration']);
	$course_desc = trim($_POST['course_desc']);
 	

 if(empty($course_name))
 {
  $error = "Please Enter Course Name!";
  $code = 1;
 }
  else if(empty($course_duration))
 {
  $error = "Please Select Course Duration!";
  $code = 2;
 }
 else if(empty($course_desc))
 {
  $error = "Please Enter Course Description!";
  $code = 3;
 }

 
 else
 {
 	$sql="insert into courses (course_name,course_duration,course_desc) values
 	 ('$course_name','$course_duration','$course_desc')";
	
	//echo $sql;
	$res=$conn->query($sql);
	if($res>=1)
	{
		echo"<script> alert('Course Created Sucessfully')</script>";
	}
	else
	{
		echo"<script> alert('error ')</script>";

	}
 }
}
?>






<script>

function check()
    {
        var cname=document.forms["form"]["course_name"].value;
        var cd_from=document.forms["form"]["course_duration"].value;
        
        var cd_des=document.forms["form"]["course_desc"].value;
		
        if(cname=="")
        {
            alert("Enter the Course");
            document.forms["form"]["course_name"].focus();
				return false;
        }
		if(cd_from=="")
        {
            alert("Fill the Course Duration");
            document.forms["form"]["course_duration"].focus();
				return false;
        }
		
		
	
		
		if(cd_des.length<1)
        {
            alert("Fill the Course description");
            document.forms["form"]["course_desc"].focus();
				return false;
        }	
		
	}

</script>


<style>
.b a h2:hover{

background-color:orange;
display:block;
border-radius:30px;
width:100px;
height:30px;
text-align:center
}
.b{margin-left:20px;
margin-top:20px;
width:80px;
}

td{padding:10px}
h1{ padding:40px;}
</style>
<body>
<div class="b">

<a href="admin_course.php"><h2>BACK</h2></a>
 </div>

<h1 align="center">ENROLL COURSE</h1>
<center>
<div align="center" style="border:3px solid red;width:500px;height:250px;background-color:#99BED3">
<form action="course.php" name="form" style="margin:10px" method="post" onsubmit="return check();">
<table>
<?php
if(isset($error))
{
 ?>
    <tr>
    <td id="error" style="color:red; "><?php echo $error; ?></td>
    </tr>
    <?php
}
?>
<tr>
<td> Batch </td> <td>
<?php
 $sql1="select * from  batch";
 $res=$conn->query($sql1);
 echo "<select name='batch'>";
 echo '<option> Choice </option>';
 while($row=$res->fetch_assoc())
 {
	 echo'<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
 }
 
 echo '</select>';
?>
</td>
</tr>


<tr><td> Course Name:</td>
 <td>   <input type="text" name="course_name"></td></tr>
	
   <tr><td>Course Duration:</td>
  <td>  <input type="text" name="course_duration" ></td></tr>
	
   <tr><td>Course Description</td>
  <td>  <input type="text" name="course_desc"></td></tr>
	
<tr><td></td><td>	<input type="submit" name="submit" value="Register"></td></tr>
</table>	
  
</form>
 </div> <br><br><br>
 </center>
 
 <?php include('../footer.php'); ?>
 
