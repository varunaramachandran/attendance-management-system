<?php include('../dbcon.php'); ?>

<?php include('../header.php'); 
include('admin_header.php'); ?>
<!DOCTYPE html>
<html>
<head><title>view</title>
<style>
table{
	text-align:center;
	border-collapse:collapse;
	width:50%;
	color:black;
	text-align:left;
	font-family:comic sans MS;
	
}
td,th{
	text-align:center;
}
th{
	background-color:#d96455;
}
</style>
</head>
<body>
<center> <br>
<h1>BATCHES</h1> <br>	
<table border="">
<tr>
<th>BATCH-NAME</th>
<th>START AT</th>
<th>END AT</th>
<th>DESCRIPTION</th>
</tr>

<?php
$sql="SELECT b_name, start_at, end_at, batch_desc from batch";
$res=$conn->query($sql);
if($res->num_rows > 0)
{
while($row=$res->fetch_assoc())
{
	echo "<tr><td>".$row["b_name"]."</td><td>".$row["start_at"]."</td><td>".$row["end_at"]."</td><td>".$row["batch_desc"]."</td></tr>";
}
echo "</table>";
}
else{
	echo "0 result";
}
$conn-> close();
?>
</table> <br><br>
</body>
</html>

<?php include('../footer.php'); ?>