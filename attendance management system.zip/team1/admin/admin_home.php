<?php 
include('../header.php');
include('admin_header.php');
//include('admin_header.php');
?>

<style>.a{display:inline-flex;padding:30px}
a{color:white}
body{background:#;}

</style>
<h1 align="center">Welcome Admin</h1>
<div class="a">
<div style="width:150px;height:330px;border-radius:10px;background-color:#5b80a4;">
<ul><center><br>
<li><a href="admin_batch.php">BATCH</a></li><br><br>
<li><a href="admin_course.php">COURSE</a></li><br><br>
<li><a href="admin_division.php">DIVISION</a></li><br><br>
<li><a href="admin_staff.php">STAFF</a></li><br><br>
<li><a href="manage_student_admin.php">STUDENT</a></li><br><br>
<li><a href="">PARENTS</a></li> <br>
</ul>
</div>
<div align="center" style="width:500px;height:200px;margin-left:220px;border-radius:10px;background-color:#5b80a4">
<ul>
	<br>
<a href="manage_student_admin.php">MANAGE STUDENTS</a><br><br>
<a href="manage_staff_admin.php">MANAGE STAFF</a><br><br>
<a href="">REQUEST</a><br><br>
</ul>
</div>

<div style="width:150px;height:330px;margin-left:220px;border-radius:10px;background-color:#5b80a4">
<ul> <center> <br>
<li><a href="view_attend">ATTENDENCE</a></li><br><br>
<li><a href="">LEAVE</a></li><br><br>
</center>
</ul>
</div>
</div>



<?php include("../footer.php");?>
