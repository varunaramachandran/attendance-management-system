<!-- coded by joish 
	validation : Client side[java script]

-->
<?php include("../header.php");
include('../admin_header.php'); ?>
<?php
include('../dbcon.php');
$b_id= $_GET['id'];


$sql="select * from batch where b_id='$b_id'";
//echo $sql;
$res=$conn->query($sql);
echo'<form name="form" style="margin:30px" method="post">';
echo '<div>
<a href="admin_batch.php"><h2>BACK</h2><a/></div>';
echo '<h1 align="center";>BATCH EDIT</h1>';
echo'<center>';
echo'<div style="border:3px solid red;width:500px;height:250px;">';
echo '<table align="center" style="margin:20px;"> <tr><td> ';
foreach ($res as $row)
{
	
	echo '<tr> <td> Batch Name:</td> <td><input type="text" name="bname" value="'.$row['b_name'].'" </td> </tr>';
	
	echo '<tr> <td> Start At:</td> <td><input type="text" name="startat" value=" '.$row['start_at'].'" </td> </tr>';
	echo '<tr> <td> End At:</td> <td><input type="text" name="endat" value=" '.$row['end_at'].'" </td> </tr>';
	echo '<tr> <td> Batch Description:</td> <td><input type="text" name="batchdesc" value=" '.$row['batch_desc'].'" </td> </tr>';
    echo '<br><tr><td><input type="submit" name="Update" value="Update"></td><td><input type="submit" name="Delete" value="Delete"</td></tr>';
	
	
}
echo '</div>';
echo '</center>';

if(isset($_POST["Update"]))
{ 	
		$bname=$_POST['bname'];
		$startat=$_POST['startat'];
		$endat=$_POST['endat'];
		$batchdesc=$_POST['batchdesc'];

		$sql2="update batch set b_name='$bname',start_at='$startat',end_at='$endat',batch_desc='$batchdesc' where b_id='$b_id'";
		//echo $sql2;
		$res2=$conn->query($sql2);
		if ($conn->query($sql2) === TRUE) {
    echo "Updated successfully";
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
		
		
		

}
if(isset($_POST["Delete"]))
{ 	

		$sql2="delete from  batch where b_id='$b_id'";
		//echo $sql2;
		
		if ($conn->query($sql2) === TRUE) {
    echo "Deleted successfully";
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
		
		
		

}


?>

