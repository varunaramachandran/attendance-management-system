<?php include("../header.php");?>

<style>.a{display:inline-flex;padding:30px}
a{color:white;text-decoration:none}

</style>
<h1 align="center">REPORTS</h1>
<div class="a">
<div style="border:2px solid red;width:200px;height:330px;border-radius:10px;background-color:#BC7D6F;">
<ul>
<li><a href="batch_report.php">BATCH REPORT</a></li><br><br>
<li><a href="course_report.php">COURSE REPORT</a></li><br><br>
<li><a href="division_report.php">DIVISION REPORT</a></li><br><br>
<li><a href="staff_report.php">STAFF REPORT</a></li><br><br>
<li><a href="student_report.php">STUDENT REPORT</a></li><br><br>
<li><a href="parent_report.php">PARENTS REPORT</a></li><br><br>
</ul> 
</div>
</div>

<?php include("../footer.php");?>
