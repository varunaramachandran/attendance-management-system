<!-- Server side validation : Prince -->

<?php include('../dbcon.php'); ?>
<?php include('../header.php'); ?>

<!DOCTYPE html>
<html>
<head><title>view</title>
<style>
table{
	
	text-align:center;
	border-collapse:collapse;
	width:30%;
	color:black;
	text-align:left;
	font-family:comic sans MS;
	
}
td,th{
	text-align:center;
	
}
th{
	background-color:#d96455;
}
td {color:#d96455; }
</style>

	<link rel="stylesheet" href="login.css">
</head>
<body>
<center>
<form method="post">
<div >
<table style="width:30%; color:red;"> <tr> <td> BATCH NAME </td> 
<td> <?php 						$sql="select * from  batch";
						$res=$conn->query($sql);
						echo '<select name="batch">';
						echo '<option> .......... </option>';
						while($row=$res->fetch_assoc())
						{
							echo'<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
						}
						
						echo '</select>';

					?>
				</td> </tr> <tr> <td> COURSE NAME </td>
<td> <?php 		
						$sql2="select * from  courses ";
						$res=$conn->query($sql2);
						echo '<select name="course">';
						echo '<option> .......... </option>';
						while($row=$res->fetch_assoc())
						{
							echo'<option value="'.$row['course_id'].'">'.$row['course_name'].'</option>';
						}
						
						echo '</select>';

?>
				</td> </tr>
<td> <input type="submit" name="submit" value="OK"  > </td> </tr>
			</table>
			</div>

<?php

if(isset($_POST['submit']) and isset($_POST['course']))
{
	$batch=$_POST['batch'];
	$course=$_POST['course'];

$sql3="SELECT * from division where batch_id=$batch and course_id=$course";
//echo $sql;
$re=$conn->query($sql3);
echo '<br><br><table border="">
<tr>
<th>DIVISION-NAME</th>
<th>INCHARGE</th> <th> </th>
</tr>';
if($re->num_rows > 0)
{	
while($row=$re->fetch_assoc())
{
	echo "<tr><td>".$row["division_name"]."</td>
	<td>".$row["incharge"]."</td>";?>
	<td><a href="division_edit.php?id='<?php echo $id; ?> '">Edit</a></td>
</tr><?php
}

}
else 
{
    echo '<script> alert(" Error: " . $sql2 . "<br>" .$conn->error); </script>';
}
echo "</table>";
$conn-> close();
}
?>
</body>
</html>



<?php include('../footer.php'); ?>