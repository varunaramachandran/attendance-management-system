<?php include("../header.php");?>
<?php include("admin_header.php");?>
<script>
function validate()
{
var bname=document.forms["batch"]["bname"];
var sdate=document.forms["batch"]["sdate"];
var edate=document.forms["batch"]["edate"];
if(bname.value=="")
        {
            alert("Enter a Valid Batch Name");
            document.forms["batch"]["bname"].focus();
				return false;
        }
if(sdate.value=="")
        {
            alert("Enter a Valid date");
            document.forms["batch"]["sdate"].focus();
				return false;
        }
if(edate.value=="")
        {
            alert("Enter a Valid date");
            document.forms["batch"]["edate"].focus();
				return false;
        }
if(cid.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["cid"].focus();
				return false;
        }
if(did.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["did"].focus();
				return false;
        }
if(tid.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["tid"].focus();
				return false;
        }
}
</script>
<html>
<head>
<style>
td,tr
{padding:10px;
 }
</style>
</head>
<body>
<center>

<br><br>
<div style="border:2px solid black; width:700px; height:350px;background:#5b80a4;margin:20px;">

<form method="POST" name="batch" onsubmit="return validate()" style="margin:20px;">
<table align="center" width="50%" border="0" style="padding:20px;"><h1 style="margin-top:10px;">Batch Insertion<h1>
<tr>
<td>Batch name:</td><td><input type="text" name="bname"></td>
</tr>
<tr>
<td >Start date:</td><td><input type="date" name="sdate"></td>
</tr>
<tr>
<td>End date:</td><td><input type="date" name="edate"></td>
</tr>
<tr>
<td>Batch Description:</td><td><input type="text" name="bdesc"></td>
</tr>
<tr>
<td></td><td><input type="submit" name="batch"value="Submit"> </td>
</tr>

</table>
</form>
</div>
</center>
</html>


<?php 

if(isset($_POST["batch"]))
{
	$bname=$_POST["bname"];
	$sdate=$_POST["sdate"];
	$edate=$_POST["edate"];
	$bdesc=$_POST["bdesc"];
	
	$sql="insert into batch (b_name,start_at,end_at,batch_desc) values ('$bname','$sdate','$edate','$bdesc')";
	//echo $sql;
	$res=$conn->query($sql);
	if($res)
	{
		echo "<script> alert('Batch Added');";
		echo 'window.location.href="admin.php"';			
		echo "</script>";
		}
	else
	{
		echo "error_get_lost";
	}
}

?>
<?php include("../footer.php");?>