<!--	
Author :Prince 
client side validation 
server side validation
Data Base Administration
 -->


<?php 
include('../header.php'); 
include('admin_header.php');
include('../dbcon.php');?>

 

<?php 
if(isset($_POST['submit']))
{
	$batch = trim($_POST['batch']);
 	$course = trim($_POST['course']);
	$div = trim($_POST['dname']);
 	$trainer = trim($_POST['trainer']);

 if(empty($batch))
 {
  $error = "please select batch!";
  $code = 1;
 }
  else if(empty($course))
 {
  $error = "please select Course!";
  $code = 2;
 }
 else if(empty($div))
 {
  $error = "Enter Division Name!";
  $code = 3;
 }
 else if(!ctype_alpha($div))
 {
  $error = "letters only !";
  $code = 3;
 }
 
 else if(empty($trainer))
 {
  $error = "Choice Teacher in charge !";
  $code = 4;
 }
 else if(strlen($div) < 4 )
 {
  $error = "Enter a Valid Name min 5!";
  $code = 3;
 }
 else
 {
 	$sql="insert into division (division_name,batch_id,course_id,incharge) values
 	 ('$div',$batch,$course,'$trainer')";
	
	//echo $sql;
	$res=$conn->query($sql);
	if($res>=1)
	{
		echo"<script> alert('DIVISION is Created ')</script>";
	}
	else
	{
		echo"<script> alert('error ')</script>";

	}
 }
}
?>
	
<script>
function validate()
{
var bname=document.forms["batch"]["bname"];
var sdate=document.forms["batch"]["sdate"];
var edate=document.forms["batch"]["edate"];
var cid=document.forms["batch"]["cid"];
var did=document.forms["batch"]["did"];
var tid=document.forms["batch"]["tid"];

if(bname.value=="")
        {
            alert("Enter a Valid Batch Name");
            document.forms["batch"]["bname"].focus();
				return false;
        }
if(sdate.value=="")
        {
            alert("Enter a Valid date");
            document.forms["batch"]["sdate"].focus();
				return false;
        }
if(edate.value=="")
        {
            alert("Enter a Valid date");
            document.forms["batch"]["edate"].focus();
				return false;
        }
if(cid.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["cid"].focus();
				return false;
        }
if(did.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["did"].focus();
				return false;
        }
if(tid.value=="choice")
        {
            alert("please select a choice");
            document.forms["batch"]["tid"].focus();
				return false;
        }
}
</script>
<html>
<head>
<style>
td
{padding:10px;
 }*
</style>
</head>
<body>
<center>


<div style="border:2px solid black; width:700px; height:350px; margin:45px;background:#5b80a4">

<form method="POST" name="batch" >
<center> <table align="center"  border="0" style="padding:20px;"><h1 style="margin-top:20px;">DIVISION<h1>
	<?php
if(isset($error))
{
 ?>
    <tr>
    <td id="error" style="color:red; "><?php echo $error; ?></td>
    </tr>
    <?php
}
?>
<tr>
<td>Batch :</td><td><?php
 
 $sql="select * from  batch";
 $res=$conn->query($sql);
 echo "<select name='batch'>";
 echo '<option> Choice </option>';
 while($row=$res->fetch_assoc())
 {
	 echo'<option value="'.$row['b_id'].'">'.$row['b_name'].'</option>';
 }
 

?></td>
</tr>


<tr>
<td>Course:</td><td><?php
 $sql1="select * from  courses";
 $res=$conn->query($sql1);
 echo "<select name='course'>";
 echo '<option> Choice </option>';
 while($row=$res->fetch_assoc())
 {
	 echo'<option value="'.$row['course_id'].'">'.$row['course_name'].'</option>';
 }
 echo "<select name='did'>";
 
 echo '</select>';

?></td>

</tr>


<tr>
<td>Dvision Name:</td><td><input type="text" name="dname"></td>
</tr>


<tr>
<td>Trainer Name:</td><td><?php
 
 
 $sql="select * from  users where user_type='Trainer'";
 $res=$conn->query($sql);
 echo "<select name='trainer'>";
 echo '<option> Choice </option>';
 while($row=$res->fetch_assoc())
 {
	 echo'<option value="'.$row['u_name'].'">'.$row['u_name'].'</option>';
 }
 echo "<select name='tid'>";
 
 echo '</select>';

?></td>
</tr>
<td></td><td><input type="submit" name="submit" value="Submit"> </td>
</tr>
</tr>
</table>
</form>
</div>
</center>
</html>




<?php include('../footer.php'); ?>